INSANIYAT DONATION — SETUP GUIDE (Roman Urdu)

1) github.com par login karein.
2) New repository banayein: insaniyat-donation. Public select karein.
3) Add file > Upload files par click karein.
4) ZIP ko apne computer par extract karein. index.html, style.css, script.js aur README files upload karein.
5) Commit changes karein.
6) Settings > Pages kholein.
7) Build and deployment mein Source: Deploy from a branch select karein.
8) Branch main aur folder /(root) select karke Save karein.
9) Kuch dair baad Pages section mein website ka link aa jayega. Is link ko Facebook post/ad mein use karein.

EASYPAISA PAYMENT ZAROORI NOTE:
"Continue to Easypaisa" button abhi official Easypaisa website kholta hai; yeh payment collect nahi karta.
Real Rs. 1 payment ke liye Easypaisa ka verified payment link ya approved merchant checkout chahiye.
Jab aapko apna official payment URL mil jaye, index.html mein https://easypaisa.com.pk/ dhoondein aur
usay apne verified payment URL se replace karein. File dobara upload/commit kar dein.
Rs. 1 ki payment support provider ke rules par depend karti hai. Fake payment confirmation na dikhayein.
