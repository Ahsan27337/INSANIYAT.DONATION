# Insaniyat Donation
Mobile-friendly charity landing page in dark green and gold. Upload `index.html`, `style.css`, and `script.js` to a public GitHub repository and enable **Settings → Pages → Deploy from a branch → main → /(root)**.

**Payment note:** The button currently opens Easypaisa's official website as a placeholder; it does not collect payment. Replace its URL only after receiving a verified payment link or approved merchant checkout.